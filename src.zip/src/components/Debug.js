import React from 'react';
import { Link } from 'react-router-dom';

const Debug = () => {
  return (
    <div>
      <Link to="/history">View History</Link>
    </div>
  );
};
export default Debug;