import React from 'react';

const LogoutButton = ({ onClick }) => (
  <button onClick={onClick}>Logout</button>
);

export default LogoutButton;