const items = [
    {
      id: 1,
      name: 'Dutch teach book',
      author: 'Kauderwelsch',
      category: 'Language',
      cover: '/1.jpg',
      price: 12,
     },
    {
      id: 2,
      name: 'The Witcher',
      author: 'Andrzey Sapkowski',
      category: 'Fiction',
      cover: '/2.jpg',
      price: 12,
   },
    {
      id: 3,
      name: 'Coralina',
      author: 'Gaiman',
      category: 'Fiction',
      cover: '/3.jpg',
      price: 5,
   },
    {
      id: 4,
      name: 'Mrs Harris goes to Paris',
      author: 'Paul Gallico',
      category: 'Comedy',
      cover: '/4.jpg',
      price: 11,
   },
    {
      id: 5,
      name: 'Unlocking the Universe',
      author: 'Stephen & Lucy Hawking',
      category: 'Science',
      cover: '/5.jpg',
      price: 14,
  }
  ]
  export default items;